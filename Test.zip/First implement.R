
# Loading packages
packages <- c("dplyr","plyr", "XML", "htmltools","xlsx",
              "foreign","tidyr", "stringr","lubridate",
              "leaflet","dygraphs", "DT","DiagrammeR",
              "threejs","mgcv","randomForest","multcomp",
              "vcd","glmnet","caret","sp","maptools","ggmap",
              "Rcpp","data.table","parallel","devtools","pracma", "Hmisc")

lapply(packages, require, character.only = TRUE)

############################################################################
############## Solving model with paper specifications of parameters #######
############################################################################

#######################################
########## Parameters #################
#######################################

#Time
t.min <- 26
t.max <- 93
T <- t.max - t.min + 1
num.choice <- 6
R <- 0.30
SD = 10000
 
par.t <- data.frame("t.min" = t.min, "t.max" = t.max, "T" = T)

### Estimated parameters from KW for College educated #############

# Utility function parameters
par.u.a1     <- 0.2519
par.u.a2     <- 1.4969
par.u.b1     <- 0.000215
par.u.b2     <- 0.000143
par.u.fracb1 <- 0.397
par.u.beta   <- 0.95

par.u <- data.frame("a1" = par.u.a1,     
                    "a2" =  par.u.a2,     
                    "b1" = par.u.b1,     
                    "b2" = par.u.b2,     
               "frac.b1" = par.u.fracb1,
                  "beta" = par.u.beta)



# Bequest parameters
par.beq.phi   <- 30000
par.beq.delta <- 25.76

par.beq <- data.frame("phi" = par.beq.phi,
                      "delta" = par.beq.delta)

# Human Capital and wage process
par.cap.lambda0 <- 0.2387
par.cap.lambda1 <- 0.9065
par.cap.lambda2 <- 0.005947
par.cap.lambda3 <- -0.0000933
par.cap.lambda4 <- 0.0001350
par.cap.lambda5 <- -0.00000038
par.cap.hours   <- 50.45
par.cap.shock.sigma   <- 0.130
par.cap.shock.mu      <- -1/2*par.cap.shock.sigma^2

par.cap <- data.frame("lambda0" = par.cap.lambda0,
                     "lambda1" = par.cap.lambda1,
                     "lambda2" = par.cap.lambda2,
                     "lambda3" = par.cap.lambda3,
                     "lambda4" = par.cap.lambda4,
                     "lambda5" = par.cap.lambda5,
                     "hours" = par.cap.hours,
                     "shock.sigma" = par.cap.shock.sigma,
                     "shock.mu" = par.cap.shock.mu)

# Fixed costs
par.fc.hours <- 127.05
par.fc.mon   <- 819.94

par.fc <- data.frame("hours" = par.fc.hours,
                     "mon" = par.fc.mon)

# Job offer probability
par.job.tprime <- 26
par.job.m1     <- 2.964
par.job.m21    <- 0.0203
par.job.m22    <- -0.0288
par.job.m23    <- -0.0286
par.job.m24    <- -0.0500
par.job.m25    <- -0.0460
par.job.m30    <- -2.652
par.job.m31    <- 0.758
par.job.m32    <- -0.0070
par.job.m33    <- -0.0150

par.job <- data.frame("tprime" = par.job.tprime, "m1" = par.job.m1,"m21" = par.job.m21,
                      "m22" = par.job.m22,"m23" = par.job.m23,"m24" = par.job.m24,
                      "m25" = par.job.m25,"m30" = par.job.m30,"m31" = par.job.m31,
                      "m32" = par.job.m32,"m33" = par.job.m33)

# Private pensions
par.pp.q1  <- -65.141
par.pp.q2  <- 2.418
par.pp.q3  <- -0.030
par.pp.q4  <- 0.000128
par.pp.q5  <- 5.573
par.pp.q6  <- -0.130
par.pp.q7  <- 0.000776
par.pp.q8  <- 3.369
par.pp.q9  <- -0.078
par.pp.q10 <- 0.000491
par.pp.q11 <- 3.387

par.pp <- data.frame("q1" = par.pp.q1, "q2" = par.pp.q2,"q3" = par.pp.q3,"q4" = par.pp.q4,
                     "q5" = par.pp.q5,"q6" = par.pp.q6,"q7" = par.pp.q7,
                     "q8" = par.pp.q8,"q9" = par.pp.q9,"q10" = par.pp.q10,"q11" = par.pp.q11)


# Social Security
par.ss.theta  <- 0.171
par.ss.B      <- 2.412

# Tax
par.tax.SD <- 7050

# Survival rates
prob.die <- 0.00824 # should be age adjusted and functional

par.sst <- data.frame("B" = par.ss.B, "theta" =  par.ss.theta, 
                      "SD" = par.tax.SD, "pdie" = prob.die )

# Setup list of variables


#######################################
## Functions ##########################
#######################################

HoursT <- function(choice) {
  if(choice == 1) h <- 0
  if(choice == 2) h <- 500
  if(choice == 3) h <- 1000
  if(choice == 4) h <- 1500
  if(choice == 5) h <- 2000
  if(choice == 6) h <- 2500 
  if(!(choice %in% seq(1:6))) print("Wrong choice in hours") else return(h)
}

# Education starting date
EduT <- function(edu) {
  x <- 0
  if (edu == "d") {
    x <- 16
  } else if (edu == "hs") {
    x <- 18
  } else if (edu == "c") {
    x <- 22
  }
  if (edu %in% c("d","hs","c")){
    return(x)
  } else {
    print("Wrong edu")
  }
}

# Utility from consumption and working hours
Util <- function(c,h,par.a1,par.a2,par.b) {
  u <- (c ^ par.a1) / par.a1 - par.b * (h ^ par.a2) / par.a2 
  return(u)
}

MargUtilCons <- function(c, par.a1) {
  u <- c ^ (par.a1 - 1)
  return(u)
}

InvMargUtilCons <- function(u.prime, par.a1) {
  c <- u.prime ^ (1 / (par.a1 - 1))
  return(c)
}

# Bequest motive from last period assets
Beq <- function(A.end, phi) {
  if (A.end > 0) {
    B <- 3*log(A.end + phi) - 1 - 3 * log(phi)
  } else {
    B <- ((A.end + phi) / phi) ^ 3
  }
  return(B)
}

# Marginal Utility of bequest motive
MargBeq <- function(A.end, phi) {
  B1 <- 3 / (A.end + phi)
  B2 <- (3 * ((A.end + phi) / phi) ^ 2) / (A.end + phi)
  MB <- ifelse(A.end > 0, B1, B2)
  return(MB)
}

### Wage and human capital process
# Deterministic capital
Cap.determin <- function(hum.cap, hours, hours.min, t, Edu.t, lambda.0, lambda.1, lambda.2, lambda.3, lambda.4, lambda.5) {
  g <- (hum.cap ^ del.1) * exp(lambda.0 + lambda.2 * max(hours - hours.min, 0) 
                               + lambda.3 * max((hours - hours.min) ^ 2, 0) 
                               + lambda.4 * (t - Edu.t(Edu.t)) 
                               + lambda.5 * (t - Edu.t(Edu.t)) ^ 2)
  return(g)
}

# test
Cap.determin(5, 10, 5, 4, "hs", del.0, del.1, del.2, del.3, del.4, del.5)

# Wages
Wage <- function(hum.cap, hours) {
  if (hours >= 1500) {
    wage = hum.cap
  } else {
    wage = 0.85 * hum.cap
  }
  return(wage)
}

# test
Wage(3,1499)

# Fixed cost of work and pre-tax income
PreTax <- function(wage, hours, fc.hours, fc.mon) {
  
  ptax <- wage * max((hours - fc.hours),0) - fc.mon * ifelse(hours > 0, 1, 0)
  
  return(ptax)
}

# test
PreTax(30000, 1500, fc.time, fc.mon)

# Job probabilities (underlying laten logit specification (remember the error term!!))
JobProbStar <- function(t,t.prime, m1, m21,m22, m23,m24,m25,m30,m31,m32,m33,p.tlast) {
  
  pjob <- m1 + m21 * (t - t.prime) * ifelse(t <= t.prime, 1, 0) 
             + m22 * (t - 30) * ifelse(t < 30, 1, 0) + m23  (t - 30) * ifelse(t > 30, 1, 0)
             + m24 * (t - 50) * ifelse(t > 50, 1, 0) + m25 * (t - 59) * ifelse(t > 59, 1, 0)
             + m30 * (1 - p.tlast) + m31 * (1 - p.tlast) * ifelse(t > 30, 1, 0)
             + m32 * (1 - p.tlast) * (t - 40) * ifelse(t > 40, 1, 0) + m33 * (1 - p.tlast) * (t - 59) * ifelse(t > 59, 1, 0)
  
  return(pjob)
}

# Social security benefits
AIME <- function(wage.t,hours.t, aime.last.t, t) {
  if (t < 35 ) {
    x <- aime.last.t + (wage.t * hours.t) / (35 * 12)
  } else {
    x <- aime.last.t + max(0, (wage.t * hours.t - aime.last.t * 12) / (35 * 12))
  }
  return(x)
}

# Primary insurance amount (2015, different for different periods)
PIA <- function(AIME) {
  PIA <- 0
  # Part 1 (till 826)
  if (AIME < 826) { 
    PIA <- 0.9 * AIME
  } else {
    PIA <- 0.9 * 826
  }
  # Part 2 
  if (AIME > 826 & AIME < 4980) {
    PIA <- PIA + 0.32 * (AIME - 826)
  } else if (AIME > 4980) {
    PIA <- PIA + (4980 - 826) * 0.32
  }
  # Part 3
  if (AIME > 4980) {
    PIA <- PIA + 0.15 * (AIME - 4980)
  } 
}

# Latent logit of getting private pension last period
dpenstar <- function(t, edu, q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11, pen.t.last) {
  p <- q1 + q2 * t + q3 * t ^ 2 + q4 * t ^ 3 +
    ifelse(edu == "hs", 1, 0) * (q5 + q6 * t + q7 * t ^2) +
    ifelse(edu == "c", 1, 0) * (q8 + q9 * t + q10 * t ^2) +
    q11 * ifelse(pen.t.last == 1, 1, 0)
  return(p)
}

# Logit of pensions
PenLogit <- function(t,edu, par.pp, pen.t.last) {
  x <- dpenstar(t, edu, par.pp$q1, par.pp$q2, par.pp$q3, par.pp$q4, 
                       par.pp$q5, par.pp$q6, par.pp$q7, par.pp$q8,
                       par.pp$q9, par.pp$q10, par.pp$q11, pen.t.last)
  prob.pen <- exp (x) / (1 + exp(x))
  return(prob.pen)
}

# Pension values based on education
Pens <- function(edu) {
  c <- ifelse(edu == "c", 23565, 0)
  hs <- ifelse(edu == "hs", 14617, 0)
  d <- ifelse(edu == "d", 8992, 0)
  p <- max(c,hs,d)
  return(p)
}

# Unemployment benefits
UnB <- function(hours, hours.last, ss, B) {
  if (hours == 0 & hours.last > 0 & ss == 0) {
    ub = B
  } else {
    ub = 0
  }
  return(ub)
}

# Taxes and progression
# capital income
CapIn <- function(asset, r) {
  cap <- (asset * r) / (1 + r)
  cap <- ifelse(cap > 0, cap, 0)
  return(cap)
}

# Taxable Income
TaxInc <- function(wage, hours, cap.inc, ss.inc, pen, SD) {
  TaxInc <- max(wage + hours + cap.inc + ss.inc + pen - SD, 0)
}

# Tax
LnTax <- function(TaxInc) {
  LnTax <- -3.9543 + 1.22563 * log(TaxInc)
}



###############################################
################ Solving the model ############
###############################################

### Setting up grids
# state spaces
# Assets grid
assets.min <- -100000 # Find some suitable values in data
assets.max <- 1000000
assets.gridpoints <- 100
assets.grid <- seq(assets.min,assets.max, length.out = assets.gridpoints)

# Human capital grid
hc.min <- 0
hc.max <- 100000
hc.gridpoints <- 100
hc.grid <- seq(hc.min, hc.max, length.out = hc.gridpoints)


# Value of last period assets (age 93)
###########################################################
########### Solution to model augmented ###################
###########################################################
# Setup policy space and values: dimensions (Time X choices X Assets X Human Capital)
Policy.Cons     <- array(dim = c(T, num.choice, assets.gridpoints, hc.gridpoints))
Policy.Hours    <- array(dim = c(T, num.choice, assets.gridpoints, hc.gridpoints))
Value           <- array(dim = c(T, num.choice, assets.gridpoints, hc.gridpoints))
Wealth          <- array(dim = c(T, num.choice, assets.gridpoints, hc.gridpoints))

# time length college:
for (t in par.t$T:1) {
  print(t)
  # Stage E (last period is assumed terminal) No human capital is entering at this point
  if (t == T) {
    for (i.hc in 1:hc.gridpoints) {
      for (i.d in 1:num.choice) {
        Policy.Cons[T,i.d,,i.hc]  <- assets.grid           # No consumption when dead
        Policy.Hours[T,i.d,,i.hc] <- 0                 # No hours after pensioning
        
        for (i.a in 1:assets.gridpoints) {  # Calculate value of bequest motive for each value of assets ()
          Value[T,i.d,i.a,i.hc] <- Beq(assets.grid[i.a], par.beq$phi) # OBS Vectorize if possible (not very time consuming though, so dont spend too much time)
        }
      }
    }
  }
  
  # Stage D: Forced pensioning (Only uncertainty is whether one recieves a private pension) Solution by regular EGM
  if (t == (92 - t.min + 1)) print("Stage D")
  if (t %in% seq((75 - t.min + 1),(92 - t.min + 1))) {                  # Runs from forced retirement (75), to time of death (92)
      
        p.pens.last   <- PenLogit(t, "c", par.pp, pen.t.last = 1) # prob of receiving if last received
        p.pens.nolast <- PenLogit(t, "c", par.pp, pen.t.last = 0) # prob of receiving if no received last
    
        # Find next period wealth as a function of end of period assets given by the equation for asset development
        # Taxation
        cap.inc       <- CapIn(assets.grid,R)  # Calculate grid of capital income OBS!!! Can easily be moved out of loop
        tax.inc.pen   <- TaxInc(0,0, cap.inc, PIA(10000), Pens("c"),SD) # AIME SET arbitrarily!! 
        tax.inc.nopen <- TaxInc(0,0, cap.inc, PIA(10000), 0,SD)
        expc.tax <- exp(LnTax(tax.inc.pen) * p.pens.last + LnTax(tax.inc.nopen) * (1 - p.pens.last)) # Weighted between receiving pensions and no pension
        
        # Next period values
        NextW <- (1 + R) * assets.grid + (p.pens.last * Pens("c")) - expc.tax                   # Asset development next period
        NextC <- predict(lm(Policy.Cons[t+1,1,,1] ~ assets.grid), newdata =  data.frame(NextW)) # Use linear interpolation and extrapolation
        NextV <- predict(lm(Value[t+1,1,,1] ~ assets.grid), newdata =  data.frame(NextW))
        
        
        # Marginal utility and computation of right hand side 
        if(t+1 == T){
          MargU <- MargBeq(NextC, par.beq$phi) # Marginal Utility of Bequest Motive
        } else {
          MargU <- MargUtilCons(NextC, par.u$a1) # Marginal Utility of consumption
        }
        
        # Calculate right hand side of the euler equation # Weighted by risk of death in next period
        if(t+1 == T){
          RHS <- (1 + R) * par.u$beta * MargU
        } else {
          RHS <- (1 - prob.die ) * (1 + R) * par.u$beta * MargU + prob.die * (1 + R) * par.u$beta * MargBeq(NextC, par.beq$phi)
        }
        
        
        # Find this period values
        Cons.t   <- InvMargUtilCons(RHS, par.u$a1)
        Wealth.t <- Cons.t + assets.grid
        Value.t  <- Util(Cons.t,0,par.u$a1,par.u$a2,par.u$b1) + par.u$beta * Value[t+1,1,,1]
        
        # Store in functions for all values of hc and work choices
        for (i.hc in 1:hc.gridpoints) {
          for (i.d in 1:num.choice) {
            Policy.Cons[t,i.d,,i.hc]   <- Cons.t
            Policy.Hours[t,i.d,,i.hc]  <- 0
            Value[t,i.d,,i.hc]         <- Value.t
            Wealth[t,i.d,,i.hc]        <- Wealth.t
          }
        }
         
        
        
  }
  if (t == (75 - t.min + 1)) print("Stage C")
  #if (t %in% seq((75 - t.min + 1),(92 - t.min + 1))) {                  # Runs from forced retirement (75), to time of death (92)
    
        #for (h.i in 1:num.choices) {                                # Loop over different choices in period t
        # for (k.i in 1:hc.gridpoints) {
            
        # Pretaxincome
        #  wage <- Wage(k.i,h.i)
        #  pre.tax.inc <- PreTax(wage,h.i)
}

plot(x=Wealth[60,3,,50], y = Policy.Cons[60,3,,50] )











