##############################
####### Model Functions ######
##############################

##############################
### Utility ##################
##############################

#Utility of consumption and work choice
Util <- function(c, h, pm) {
  ### Utility function of the consumption and labour supply choices
  
  c <- c * 1/ 1
  
  # Convert parameters
  a1 <- pm[1]
  a2 <- pm[2] 
  b  <- pm[3]
  
  # Convert to hours
  h.time = Hours(h)
  
  # Calculate utility
  u <- (c ^ a1) / a1 - b * (h.time ^ a2) / a2 
  return(u)
}

# Marginal utility of consumtion
MargUtil <- function(c, pm){
  ### Marginal utility with respect to consumption
  
  # Convert from vector
  a1 <- pm[1]
  
  # Calculate marginal Utility
  u <-  c ^ (a1 -1)
  return(u)
}

# Inverse Marginal Utility of consumption
InvMargUtil <- function(u, pm){
  ### Inverse marginal utility for solving the euler equation
  
  # Convert from vector
  a1 <- pm[1]
  
  # Find consumption values
  c = u ^ (1 / (a1 - 1))
  return(c)
}

# Bequest motive
Beq <- function(A, pm, px) {
  # Bequest motive for end of time period utility
  phi <- px$phi
  
  B <- ifelse(A > 0,
              3*log(A + phi) - 1 - 3 * log(phi),
              ((A + phi) / phi) ^ 3)
  
  B <- B * pm[4]
  return(B)
}

################################
### Labour Market ##############
################################
# Wages
WageHourly <- function(t, k, px, p1){ 
  
  Age <- t + px$t.min - 1
  
  w <-p1$w01 + 
      p1$alpha11 * k + 
      p1$alpha12 * k ^ 2 + 
      p1$alpha13 * Age + 
      p1$alpha14 * Age ^ 2 + 
      p1$alpha15 * Age ^ 3 + 
      p1$alpha16 * Age * k

  return(w)
  
}

# Hours discretised
Hours <- function(h){
  #############################
  # Converts the indicator for the discrete choice of hours into its numerical counterpart
  
  ht <- ifelse(h == 6, 2500,
               ifelse(h == 5, 2000,
                      ifelse(h == 4, 1500,
                             ifelse(h == 3, 1000,
                                    ifelse(h == 2, 500,
                                           ifelse(h == 1, 0,0))))))
  
  return(ht)
}

# Fixed cost of work
FCW <- function(t, k, h, pm, px, p1){
  ##########################
  # Fixed cost of work given
  # 
  hours <- Hours(h)
  
  fc.h <- 127
  fc.m <- 4900
  
  E <- (WageHourly(t,k,px, p1) * pmax(hours - fc.h,0) - fc.m * (h > 1)) 
  
  return(E)
}

# Unemployment Benefit 
UnemBen <- function(t,k,h, px, p1){
  # Calculates unemployment benefits
  # Input:
  # t: Full time years of insurance left
  # h: Part time years of insurance left
  # h: labour supply
  # w.full: wage if full time
  # w.part: wage if part
  
  # Correcting back scale and age
  Age <- t + px$t.min - 1
  
  # Wage if fulltime (unscaled to get correct parameter)
  wfull <- WageHourly(t,k,px,p1) * ((Hours(4) + Hours(5))/2)
  wpart <-  WageHourly(t,k,px,p1) * ((Hours(2) + Hours(3))/2) 
  
  # Unemployed
    ubf <- p1$mu10 + 
            p1$mu11 * log(Age) + 
            p1$mu12 * Age + 
            p1$mu13 * wfull +
            p1$mu14 * wfull ^ 2 
    
    # Part time employed
    ubp <- p1$mu20 + 
          p1$mu21 * log(Age) + 
          p1$mu22 * Age + 
          p1$mu23 * wpart +
          p1$mu24 * wpart ^ 2 
    
  ubf <- ifelse(ubf > 0,ubf,0)
  ubp <- ifelse(ubp > 0,ubp,0)
  
  ub <- ifelse(h == 1, ubf, ifelse(h %in% part.t, ubp, 0))
    
  return(ub)
}

# Capital income
CapIn <- function(A, px) {
  
  cap <- (A * px$R) / (1 + px$R)
  
  cap <- ifelse(cap > 0, cap, 0)
  
  return(cap)
}

# Taxation
TaxF <- function(ti, px, p1){
  # Uses the deltas from the first stage regressions to calculate taxation
  
  ti <- ti 
  
  tax <- p1$delta0 + 
    p1$delta1 * pmin(ti, px$kink1) +
    p1$delta2 * pmin(pmax(ti - px$kink1, 0), px$kink2 - px$kink1) + 
    p1$delta3 * pmax(ti - px$kink2, 0)
  
  tax <- pmax(tax,0) 
  return(tax)
}

# Pension
Pens <- function(k,px,p1){
  
  P <- p1$gamma0 + 
    p1$gamma1 * k +
    p1$gamma2 * k ^ 2 +
    p1$gamma3 *k ^ 3 
  
  return(P )
}

# Deductions
Deduc <- function(A,t,k,px,p1){
  
  A1 <- A 
  WH <- WageHourly(t,k,px,p1)
  
  D <- p1$d0 + 
    p1$d1 * log(A1) +
    p1$d2 * WH + 
    p1$d3 * WH ^ 2  +
    p1$d4 * WH ^ 3
  
    D <- ifelse(ifelse(is.na(D),0,D)>30000,D,30000)
  
    return(D)
}

# Job offer probabilities
JProb <- function(t, k, px, p1) {
  #################################################
  # Description
  #
  # Calculates the job offer probability in next period given current period labour supply
  # Arg.:
  # t: age
  # ul: Indicator for whether or not the agent was employed in former period
  # k: Human capital 
  #################################################################################
  
  # Calculate real age level
  t <- t + px$t.min - 1
  
    # Latent logit equation for the logit specification
    pjob <- ( 
      # Age and splines
      p1$m0 + 
        p1$m11 * t +
        p1$m12 * t ^ 2 +
        p1$m13 * (t - 30) * (t > 30) +
        p1$m14 * (t - 45) * (t > 45) +
        p1$m15 * (t - 55) * (t > 55) +
        
        # Age spliens if unemployed
        p1$m21 * k +
        p1$m22 * k ^ 2 +
        p1$m23 * (t - 30) * (t > 30) * k  +
        p1$m24 * (t - 45) * (t > 45) * k +
        p1$m25 * (t - 55) * (t > 55) * k 
      
    )
    
  # Calculate Logit Prob.
  J <- exp(pjob) / (1 + exp(pjob))
  
  return(J)
}

###########################
####### DC - EGM ##########
###########################

# Logsum 
LogSum <- function(NextV, px){
  ##################################################
  # Calculates logsum values of 
  # choice specific value functions
  # 
  # Inputs
  # NextV: num.A X px$num.h matrix of next period choice specific values
  # Sigma: taste shock parameter
  #
  # Output
  # logsum: logsum values vector of expected values
  ##################################################
  
  sigma <- px$sigma.taste
  
  logsum <- rep(0, nrow(NextV))
  
  # Loop over choices
  for (d in 1:px$num.h){
    
    logsum <- logsum + exp(NextV[,d])
    
  }
  
  # Take logsum
  logsum <- sigma * log(logsum)
  
  return(logsum)
}

# Choice probabilities
ChoiceProb <- function(NextV, px){
  ####################################################
  # Calculates choice probabilities for next period
  # of choice specific value functions
  # 
  # Inputs
  # NextV: num.A X px$num.h of next period choice specific values
  # Sigma: taste shock parameter
  #
  # Output
  # Choice prob: num.grid X choice prob matrix
  ####################################################
  
  sigma <- px$sigma.taste
  
  cp <- array(0, dim = dim(NextV))
  
  expsum <- rowSums(exp(NextV))
  
  # Loop over choices
  for (d in 1:px$num.h){
    
    cp[,d] <- exp(NextV[,d]) / expsum
    
  }  
  
  return(cp)
}

# Robust Logsum/CP functions
LogCP <-  function(NextV,px){
  ##################################################
  # Calculates logsum values and choice probabilities
  # using a recentered version of the closed form solutions
  # to account for numerical instability
  # 
  # Inputs
  # NextV: num.A X px$num.h matrix of next period choice specific values
  # Sigma: taste shock parameter
  #
  # Output
  # logsum: logsum values vector of expected values
  ##################################################
  
  sigma <- px$sigma.taste
  
  Vmax <- matrix(rowMax(NextV))
  
  #Logsum
  emax <- NextV - matrix(rep(Vmax,px$num.h), nrow= nrow(NextV), ncol = ncol(NextV))
  logsum <- Vmax + sigma * log(rowSums(exp(emax / sigma)))
  
  # Choiceprob
  logdif <- NextV - matrix(rep(logsum,px$num.h), nrow= nrow(NextV), ncol = ncol(NextV))
  cp <- exp(logdif / sigma)
  
  out <- list("Logsum" = logsum, "Choiceprob" = cp)
  return(out)
  
}

# Unequal asset grid
UnEqualGrid <- function(px){
  # Constructs grid with more bottom mass for better 
  # approximation of curvature in the utility function
  
  lo  <- px$a.min
  hi  <- px$a.max
  n   <- px$num.a 
  phi <- px$uneq
  
  w <- rep(0,n)
  w[1] <- lo
  for (i in 2:n){
    w[i] <- w[i-1] + (hi-w[i-1])/((n-i+1)^phi)
  }
  
  
  return(w)
}
UEGridM <- function(px){
  # For use in common grid upper envelope, to avoid EDG over max levels of posible interp values
  lo  <- px$a.min
  hi  <- px$a.max * 1.5
  n   <- px$num.a
  phi <- px$uneq
  
  w <- rep(0,n)
  w[1] <- lo
  for (i in 2:n){
    w[i] <- w[i-1] + (hi-w[i-1])/((n-i+1)^phi)
  }
  
 
  
  return(w)
}
UEplot <- function(lo,hi,n,phi){
  # Constructs grid with more bottom mass for better 
  # approximation of curvature in the utility function
  
  w <- rep(0,n)
  w[1] <- lo
  for (i in 2:n){
    w[i] <- w[i-1] + (hi-w[i-1])/((n-i+1)^phi)
  }
  
  
  return(w)
}

# EGM Step 
EGM <- function(A, t, n.r, n.c, n.v, h, k, k.markov, pm, px, p1, Sim, sim.args){
  #########################################################################################
  # Description 
  #
  # Solves optimal consumptypion and value for a given set of state variables
  # and a discrete choice h
  #
  # # Input:
  # Grids:
  # n.r:    (M) Next period wealth/cash on hand to use for interpolation (grid)
  # n.c:    c(M,h)_(t+1) Next period optimal consumption given next wealth (M) and choice h (C[t,,,,])
  # n.v:    v(M,h)_(t+1) next period value given M and h
  # A:      End of period Asset grid
  #
  # Scalars:
  # t:        Current time period (t<T)
  # k:        Level of human capital in t
  #
  # Parameters:
  # pm: Model parameters to be estimated
  # px: Model parameters exogenously given
  # p1: Model parameters from first stage
  #    
  # Sim.args: Controls for simulation specifications
  #
  # # Output:
  # M:        Endogenous grid of starting resources    
  # C(M,h)_t: Consupx$mypion for M and h 
  # C(M,h)_t: Value of for M and h
  ########################################################################################
  
  ### Storage Matrices ####
  # Solutions
  C <- rep(NA, length(A))
  M <- C
  
  ## Work indicator for next period   
  ul <- ifelse(h != 1, 0, 1)
  
  ### Income ##
  # Wage income
  WI <- WageHourly(t, k, px, p1) * Hours(h)
  
  # Capital income
  CI <- CapIn(A, px) # Capital income over period
  
  # Unemployment benefits
  UB  <- UnemBen(t,k, h, px, p1)
  
  # Deductions
  DE <- Deduc(A, t, k, px, p1)
  
  # Taxable income
  TI <- CI + WI + UB - DE
  
  # Taxation baseline and simulations
  if(Sim == TRUE && sim.args$Trans == FALSE){
    if(sim.args$S1 == "Tax" | sim.args$S2 == "Tax"){
      
      Tax <- TaxF(TI, px, p1) + 0.05 * WageHourly(t, k,h, px, p1) * Hours(h) 
      
    }
    
  } else {
    
    Tax <- TaxF(TI, px, p1) 
    
  }
  
  # Subtracting fixed cost of work
  Inc <- FCW(t,k,h,pm,px,p1)
  
  # Basic income 
  if(Sim == TRUE && sim.args$Trans == FALSE){
    
    BI <- ifelse(sim.args$S1 == "BI" | sim.args$S2 == "BI",sim.args$BI, 0)
    
  } else {
    BI <- 0
  }
  
  ## Next period wealth
  NextW <-(1 + px$R) * A + Inc + UB + CI - Tax + BI
  
  # Job probability next period 

  Jprob <- JProb(t, k, px, p1)
  
  k.markov <- K.Markov
  
  ### Look up transition probabilities in markov chain given h ###
  trans.prob      <- k.markov[[h]][k,]
  nonzero.k       <- which(k.markov[[h]][k,] != 0)
  nonzero.k
  # Storage
  RHS <- 0
  EV  <- 0
  
  # Next period values for h decision
  NextC  <- array(NA, dim = c(length(A), px$num.h)) 
  NextV  <- NextC
  
  # Loop over K's in human capital
  for(n.k in nonzero.k) {
    
    #### For each h in t+1, compute value and cons #####
    for(d in 1:px$num.h){
      NextC[,d]  <- approxExtrap(x  = n.r[d, n.k, ],  # Next period endogenous resources (EG_t+1)
                                 y  = n.c[d, n.k, ],        # Net period consupx$mypion given EG_t+1
                                 xout = NextW)$y                            
      
      NextV[,d]  <- approxExtrap(x  = n.r[d, n.k, ],
                                 y  = n.v[d, n.k, ], 
                                 xout = NextW)$y
    }
    
    
    # Calculate choice probabilities conditional on timeperiod
    # If next period is terminal, h = 1 is certain
    
    LCP <- LogCP(NextV,px)
    
    if(t < (px$T-1)){
      
      choiceprob  <- LCP$Choiceprob
      
    } else {
      
      choiceprob <- matrix(c(rep(1,px$num.a),zeros(n = px$num.a, m = px$num.h-1)), nrow = px$num.a, ncol = px$num.h)
      
    }
    
    # Expected marginal utilities given choice probabilities
    EMUWork <- rep(0, length(A))
    
    # Expected marginal utility when agent have joboffer next period
    for (d in 1:px$num.h){
      EMUWork <- EMUWork + choiceprob[,d] *  MargUtil(NextC[,d],pm)
    } 
    
    # Expected marginal utility when agent do not have job offer next period
    EMUunempl <- MargUtil(NextC[,1],pm)
    
    # Expected consumtion by job probability
    ExpMargUtil <- Jprob * EMUWork + (1 - Jprob) * EMUunempl
    
    ## Collect terms and multiply with transition probs
    # Right hand side of euler equation
    RHS <- RHS + (px$beta * (1 + px$R ) * ExpMargUtil * trans.prob[n.k])
    
    # Expected value as logsum weigthted by job probability
    EV <- EV + (LCP$Logsum * trans.prob[n.k])
  }
  
  # EGM solution to consupx$mypion C, Start of period assets M and Value V
  C <- InvMargUtil(RHS, pm)
  M <- A + C
  V <- Util(C, h, pm) + px$beta * EV
  
  # Add the interpolated constrained solution
  Ms <- min(M)
  As <- min(A)
  subGrid <- seq(from=As, to = Ms-10^-6, length.out = px$cons)
  Cs <- subGrid
  Vs <- Util(Cs,h,pm) +px$beta * EV[1]
  
  # Add points
  M <- c(subGrid,M)
  C <- c(Cs,C)
  V <- c(Vs,V)
  
  # Remove points ro preserve dimensionality
  ind.out <- round(seq(from = px$cons, to = px$num.a, length.out = px$cons))
  C <- C[-ind.out]
  M <- M[-ind.out]
  V <- V[-ind.out]
  
  # Detect non-monotonicity in the endogenous grid and run upper envelope refinement if found
  # if(sum(diff(M)<0)>0){
  #   UE <- UpperEnvelope(C,V,M,px)
  #   C <- UE$C
  #   M <- UE$M
  #   V <- UE$V
  # }
  # 
  # Combine in dataframe and return
  out <- data.frame("C" = C, "V" = V, "M" = M)
  return(out)
}

# Upper Envelope
UpperEnvelope <- function(C,V,M,px){
  ##### Description ###################################################################
  #
  # Calculates the upper envelope of the solution
  # converting the solution from a multivalued correspondance to a one-to-one function
  # between endogenous grid resources and C/V values
  # 
  # Input:
  # M: Endogenous grid of resources
  # C: consumyption correspondance to M at choice h_t
  # V: Values corresponding to Consupx$mypion C, choice h and resources M
  # All are found for a given constellation of S={FTY,PTY,i.p,i.k}
  # 
  # Output
  # uM: refined upper envelope values of EDG
  # uC: refined upper envelope values of consumption
  # uV: refined upper envelope values of value function
  # 
  # Credit: All code is translated directly from the solution given in
  # Ishakov et. al. 2017, and the related Matlab code by 
  # Thomas J�rgensen on tjeconomics.dk
  #####################################################################################
  
  Fall <- 0 
  Increase <- 1
  i <- 2
  while(i <= px$num.a -1) {
    if(M[i+1] < M[i] & M[i] > M[i-1] | V[i] < V[i - 1] & M[i] > M[i-1]) { # Detect the non-concave regions
      Fall <- ifelse(Fall == 0, i, c(Fall, i))
      k <-  i
      while(M[k+1] < M[k]){
        k <- k + 1
      }
      Increase <- c(Increase, k)
      i <- k
    }
    i <- i + 1
  }
  Fall <- c(Fall, px$num.a)
  n.kinks <- length(Fall)
  NumP <- px$num.a
  CommonM <- UEGridM(px)
  CommonV <- (-1 * 10 ^ 7) * ones(NumP, n.kinks)
  CommonC <- NaN * ones(NumP, n.kinks)
  
  for(j in 1:n.kinks){
    InRange <- which(M[Increase[j]] > CommonM & M[Fall[j]] < CommonM)
    CommonV[InRange,j] <- approxExtrap(M[Increase[j]:Fall[j]],
                                       V[Increase[j]:Fall[j]], 
                                       xout=CommonM[InRange])$y
    
    CommonC[InRange,j] <- approxExtrap(M[Increase[j]:Fall[j]],
                                       C[Increase[j]:Fall[j]], 
                                       xout=CommonM[InRange])$y 
    
  } 
  uVt <- apply(CommonV,1,FUN = max)
  id  <- which(CommonV == uVt)
  uM  <- CommonM
  if(is.na(uVt[1])){
    uVt[1] <- 0
    CommonC[1,1] <- uM[1]
  }
  # Extrapolate if sub-segs goes outside common grid yileding NA
  isNA          <- which(is.na(uVt) == TRUE)
  uVt[isNA]     <- approxExtrap(uM[-isNA], uVt[-isNA], uM[isNA])$y
  LastBeforeNA  <- min(which(is.na(uVt) == TRUE)) - 1
  LastId        <- id[LastBeforeNA]
  id[isNA]      <- LastId
  
  # Consumption by linear indexation
  LinInd <- cumsum(ones(px$num.a,1))+(id - 1)*px$num.a
  uC <- CommonC[LinInd]
  uC[isNA] <- approxExtrap(uM[-isNA], uC[-isNA], uM[isNA])$y
  
  out <- list("C" = uC, "M" = uM, "V" = uVt)
  return(out)
}

# Solution wrapper for parallel computing
SolutionWrapper <- function(Avec,i.h,t,n.r,n.c,n.v, k.markov, pm, px, p1, Sim, sim.args){
  #########################################################################################
  # Description 
  #
  # Solves optimal consupx$mypion and value for a given set of state variables
  # and a discrete choice h
  # The wrapper is created to assure "Embarrassingly Parallel" runs of the EGM solution 
  # on maximum number of statespace points on a single CPU core
  #
  # #Input:
  # Grids:
  # n.r:    (M) Next period wealth/cash on hand to use for interpolation (grid)
  # n.c:    c(M,h)_(t+1) Next period optimal consupx$mypion given next wealth (M) and choice h (C[t,,,,])
  # n.v:    v(M,h)_(t+1) next period value given M and h
  # A:      End of period Asset grid (Skal muligvis v�re et punkt)
  #
  # Scalars:
  # t:        Current time period 
  # h:        choice of labour supply
  #
  # # Output:
  # M:        Endogenous grid of starting resources    
  # C(M,h)_t: Consupx$mypion for M and h at t and State space k X YU
  # V(M,h)_t: Value of for M and h at t and State space k X YU
  ##########################################################################################
  
  W.C <- array(NA, dim = c(px$num.k,  # Human capital
                           px$num.a)) # Asset grid))
  
  W.V <- W.C
  W.M <- W.C 
  
  for (i.k in 1:px$num.k){ 
    
    if(t == px$T) {
      # Bequest solution
      W.M[i.k, ] <- Avec
      W.C[i.k, ] <- Avec
      
      # Wealth with pensions
      Pen <- Pens(i.k,px,p1)
      W.V[i.k,] <- Beq(Avec + Pen, pm, px)
    }                                        
    
    if(t < px$T){
      
      #### Solve model by EGM ####
      # Each solution to a given choice of h runs parallel and is returned as combined list
      sol.w <- EGM(A         = Avec,
                   n.r    = n.r,
                   n.c    = n.c,
                   n.v    = n.v,
                   h      = i.h,
                   k      = i.k,
                   t      = t,
                   k.markov = k.markov,
                   px = px,
                   pm = pm,
                   p1 = p1, 
                   Sim = Sim,
                   sim.args = sim.args)
      
      # Store solution values
      W.M[i.k, ] <- sol.w$M
      W.C[i.k, ] <- sol.w$C
      W.V[i.k, ] <- sol.w$V
    }
  }
  
  SolutionWL <- list(W.M, W.C, W.V)
  return(SolutionWL)
}

# Full solution function
SolveEGM <- function(pm, px, p1, Sim, sim.args){
  #########################################################################################
  # Description 
  #
  # The full solver for all statespace choice and timepoints at a given set of parameters
  # Required solution function to maximum likelihood estimator  
  #
  # Input:
  # par.m: Parameters of the model to be etimated
  # par.ex: Exogenously given parameters of the model. Not estimated, or estimated in first step
  #  
  # Returns:
  # M_s,t:            Endogenous grid of starting resources for all states and times S X T   
  # C(M,h,S)_t: Consupx$mypion for M for all states, times and choices S X T X H
  # V(M,h,s)_t: Value of for M for all states, times and choices S X T X H
  #########################################################################################
  
  Avec <- UnEqualGrid(px)   
  
  Solution.C <- array(NA, dim = c(px$T,       # Time
                                  px$num.h,   # h choices
                                  px$num.k,   # Human cap
                                  px$num.a))  # Avec))
  
  Solution.V <- Solution.C
  Solution.M <- Solution.C 
  
  #print("Start Solution")
  for (t in px$T:1){
    #print(paste0("Start t=",t))
    # Time tracker
    
    if(t < px$T) {
      n.r <- Solution.M[t+1, , , ]
      n.c <- Solution.C[t+1, , , ]
      n.v <- Solution.V[t+1, , , ]
    } 
    
    for(i.h in 1:px$num.h){
    # Initialise parrallelization
     for (i.k in 1:px$num.k){ 
      
        if(t == px$T) {
          # Bequest solution
          Solution.M[t, i.h ,i.k, ] <- Avec
          Solution.C[t, i.h ,i.k, ] <- Avec
          Solution.V[t, i.h ,i.k, ] <- Beq(Avec,pm,px)
          
        }                                        
      
        if(t < px$T){
        
        #### Solve model by EGM ####
        # Each solution to a given choice of h runs parallel and is returned as combined list
        SolEGM <- EGM(A      = Avec,
                      t      = t,
                      n.r    = n.r,
                      n.c    = n.c,
                      n.v    = n.v,
                      h      = i.h,
                      k      = i.k,
                      k.markov = K.Markov,
                      px = px,
                      pm = pm,
                      p1 = p1, 
                      Sim = Sim,
                      sim.args = sim.args)
        
        
        
        
        # Store solution values
        Solution.M[t, i.h ,i.k, ] <- SolEGM$M
        Solution.C[t, i.h ,i.k, ] <- SolEGM$C
        Solution.V[t, i.h ,i.k, ] <- SolEGM$V
      }
    }
    }
    
    #print(paste0("End t=",t))
   #if(t %in% c(12,22,32,41))   print(paste0("Solution time: ", px$T - t +1, " of ", px$T))
   # if(t == 1) print("Solution - Done!")
  }
  
  out <- list("C" = Solution.C, "M" = Solution.M, "V" = Solution.V)
  return(out)
}
# Speed Test of Full solution function
time <- system.time(SolveEGM(pm,px,p1,Sim, sim.args))
print(paste0("System time: ",round(time[[3]],2), " sec. / ", round(time[[3]]/60,2), " min. per solution"))

###################################
##### Maximum Likelihood ##########
###################################

# Wrapper function for parallel computing
InterpWrapperLogLike <- function(i.h,df.est,Solution.C, Solution.M, Solution.V, px){
  ##################################################################################
  # Description
  #
  # Wrapper function for parallel interpolation of predicted values and consumption
  # form df.est state variables
  # 
  # Input:
  # i.h: choice index
  # df.est: df.estset from registerdf.est, N X 12 vars
  # Solution.C/V: Model soluion to consumption and values
  # Solution.M: Model endogenous grid to interpolate on
  #
  # Output:
  # IntC: Interpolated consumption predicted from model solution
  # IntV: Interpolated values predicted from model solution
  ###################################################################################
  
  N <- nrow(df.est)
  IntV <- array(NA, dim = c(N,px$T, px$num.k))
  IntC <- IntV
  
  for(t in 1:px$T){
    for(i.k in 1:px$num.k){
      
      IntC[, t,i.k] <- approxExtrap(Solution.M[t,i.h, i.k, ],
                                    Solution.C[t,i.h, i.k, ],
                                    df.est$wealth)$y
      
      IntV[, t,i.k] <- approxExtrap(Solution.M[t,i.h, i.k, ],
                                    Solution.V[t,i.h, i.k, ],
                                    df.est$wealth)$y
    }
  }
  
  out <- list("IntC" = IntC, "IntV" = IntV)
  return(out)
  
}

# LogLikelihood function
LogLikelihood <-function(df.est,Solution.C, Solution.M, Solution.V, px) {
  ##################################################################################
  # Description
  #
  # Loglikelihood calculation for estimating model parameters
  # 
  # Input:
  # df.est: df.estset from registerdf.est, N X 12 vars
  # Solution.C/V: Model soluion to consumption and values
  # Solution.M: Model endogenous grid to interpolate on
  #
  # Output:
  # llike: Sum of loglikelihood contributions
  # ProbH: Probability of the made choice given model solution
  ###################################################################################
  
  
  # Number of obs
  N <- nrow(df.est)
  N
  # Storage for interpolated values on choice and statse
  AltV  <- array(NA, dim = c(N, px$T, px$num.h ,px$num.k))
  AltC <- AltV
  
  # Do a parrallel loop over h from wrapper
  InterpCV <- lapply(1:px$num.h,FUN =
                       function(x){InterpWrapperLogLike(i.h=x,
                                                        df.est,
                                                        Solution.C, 
                                                        Solution.M,
                                                        Solution.V,px)})
  
  # Collect term
  for(i.h in 1:px$num.h){
    
    AltC[ , ,i.h, ] <- InterpCV[[i.h]]$IntC
    AltV[ , ,i.h, ] <- InterpCV[[i.h]]$IntV
    
  }
  
  PredC <- matrix(nrow = N)
  PredVh <- matrix(nrow = N,ncol = px$num.h)
  
  # Look up values for each observation
  
  Obs <- 1:N
  
  PredC <- AltC[cbind(Obs,df.est$t,df.est$ht,df.est$k)]
  
  for(i.h in 1:px$num.h){
    
    PredVh[,i.h] <- AltV[cbind(Obs,df.est$t,i.h,df.est$k)]
  }
  
  # Model Value
  value <- PredVh[cbind(Obs, df.est$ht)]
  
  # Calculate logsum
  logsum <- LogCP(PredVh, px)$Logsum
  
  # Calculate Choice probs for use in model fit illustrations
  #expsum <- rowSums(exp(PredVh / px$sigma.taste))
  #probH <- (exp(value / px$sigma.taste)) / expsum
  
  # Choicepart of the likelihood
  choicepart <- 1 / px$sigma.taste * (value - logsum)
  
  # Remove non-jobreceivers from choicepart
  choicepart <- ifelse(df.est$joboffer == 1, choicepart, 0)
  
  # Consumption part of likelihood
  conspart <- - 1 / 2 * log((df.est$cons - PredC) ^ 2)
  
  # Individual likelihoods
  IndLL <- choicepart + conspart
  
  # Total likelihood
  LogLike <- sum(choicepart + conspart)
  
  # Return output
  out <- list("SumLL" = LogLike, "IndLL" = IndLL)
  
  return(out)
}

# Combined Solution and Likelihood function
FullLogLike <- function(df.est,pm,px,p1){
  ##################################################################################
  # Description
  #
  # Combined solution and loglikelihood function for a given df.est and parameterset
  # 
  # Input:
  # df.est: df.estset from registerdf.est, N X 12 vars
  # pm: model parameters to be estimated
  # px: model parameters exogenously given 
  #
  # Output:
  # llike: Sum of loglikelihood contributions
  # ProbH: Probability of the made choice given model solution
  ###################################################################################
  
  Solution <- SolveEGM(pm,px,p1,Sim,sim.args)
  
  llike <- LogLikelihood(df.est,
                         Solution.C = Solution$C,
                         Solution.M = Solution$M,
                         Solution.V = Solution$V, px)
  
  print("End Likelihood")
  return(llike)
}

# Handles for optimizer
# Sum of LogLikelihoods
LLSum <- function(pm) {
  # LogLike handle to feed to maximizer
  # Returns LL sum
  ll <- FullLogLike(df.est,pm,px,p1)
  ll <- ll$SumLL
  return(ll)
}

# Individual observations of LL for BHHH algorithm
LLObs <- function(pm) {
  # LogLike handle to feed to maximizer
  # Return individual LL contributions for all observations
  ll <- FullLogLike(df.est,pm,px,p1)
  ll <- ll$IndLL
  return(ll)
}

# Test
time <- system.time(FullLogLike(df.est, pm,px,p1))
print(paste0("MLE evaluation time: ",round(time[[3]],2), " sec. / ", round(time[[3]]/60,2), " min."))


########################################################################

# Not used in paper
# Deathrates 
DProb <- function(t){
  if(t %in% 25:29) {
    d <- 0.00107
  } else if(t %in% 30:34) {
    d <- 0.00146
  } else if(t %in% 35:39) {
    d <- 0.00206
  } else if(t %in% 40:44) {
    d <- 0.00298
  } else if(t %in% 45:49) {
    d <- 0.00424
  } else if(t %in% 50:54) {
    d <- 0.00669
  } else if(t %in% 55:59) {
    d <- 0.01144
  } else if(t %in% 59:64) {
    d <- 0.01933
  } else if(t %in% 65:69) {
    d <- 0.0309
  } else if(t %in% 70:74) {
    d <- 0.04917
  } else if(t %in% 75:79) {
    d <- 0.07602
  } else if(t %in% 80:84) {
    d <- 0.11718
  } else if(t %in% 85:95) {
    d <- 0.21428
  } else {
    d <- 1 
  }
  return(d)
}

# Starting age from different education levels
EduT <- function(edu) {
  x <- 0
  if (edu == "d") {
    x <- 16
  } else if (edu == "hs") {
    x <- 18
  } else if (edu == "c") {
    x <- 22
  }
  if (edu %in% c("d","hs","c")){
    return(x)
  } else {
    print("Wrong edu")
  }
}

# interpolation functions
LinInt <- function(x, y, x0vec){
  # Storage vector
  int.out <- NA
  
  # Find larger than grid linear parameters
  ndx  <- order(x, decreasing = T)[1:2]
  xmax <- x[ndx]
  
  A.max <- (y[ndx[1]] - y[ndx[2]]) / (xmax[1] - xmax[2])
  B.max <- y[ndx[1]] - A.max * xmax[1]
  
  # Find lower than grid linear parameters
  ndx <- order(x)[1:2]
  xmin <- x[ndx]
  
  A.min <- (y[ndx[1]] - y[ndx[2]]) / (xmin[1] - xmin[2])
  B.min <- y[ndx[2]] - A.min * xmin[2]
  
  for(i in 1:length(x0vec)){
    x0 <- x0vec[i]
    
    if(x0 < max(x) && x0 > min(x)){
      
      int <- approx(x,y,xout = x0)
      int <- int$y
      # print(paste0( "middle",int))
    } else if(x0 >= max(x)) {
      
      int <- B.max + A.max * x0
      # print(paste0( "over",int))
    } else if(min(x) >= x0) {
      
      int <- B.min + A.min * x0
      # print(paste0( "under",int))
    } else {
      
      print("interpolation error")
      
    }
    int.out <- c(int.out, int)
  }
  return(int.out[-1])
}

# Terminal consumption
TermCons <- function(A,k,px,p1){
  A1 <- A * 
    
  c <- p1$gamma0 +
    p1$gamma1 * A1 + 
    p1$gamma2 * A1 ^ 2+ 
    p1$gamma3 * k + 
    p1$gamma4 * k ^ 2
  
  c <- c 
  
  return(c)  
}

#########################################
### Motions of deterministic states #####
#########################################

# part time last period
Nextpl <- function(h){
  
  n.pl <- ifelse(h %in% part.t, 2,1)
  
  return(n.pl)
  
}

# Eligibility
NextEL <- function(h,pl,EL,mEL){
  if(h %in% full.t){
    
    n.EL <- mEL
    
  }
  
  if(h %in% part.t) { # ?
    
    if (pl == 1) {
      
      n.EL <- max(EL - 1, 1)
      
    } else { 
      
      n.EL <- mEL 
      
    }
  }
  
  if(h == 1) {
    
    n.EL <- max(EL - 1, 1)
    
  }
  
  return(n.EL)
  
}