########################################################
############## Estimation ##############################
########################################################

# Wrapper function for parallel computing
InterpWrapperLogLike <- function(i.h,DATA,Solution.C, Solution.M, Solution.V, px){
  ##################################################################################
  # Description
  #
  # Wrapper function for parallel interpolation of predicted values and consumption
  # form data state variables
  # 
  # Input:
  # i.h: choice index
  # DATA: Dataset from registerdata, N X 12 vars
  # Solution.C/V: Model soluion to consumption and values
  # Solution.M: Model endogenous grid to interpolate on
  #
  # Output:
  # IntC: Interpolated consumption predicted from model solution
  # IntV: Interpolated values predicted from model solution
  ###################################################################################
  
  N <- nrow(DATA)
  IntV <- array(NA, dim = c(N,px$T, px$num.k, px$mEL, px$p.last))
  IntC <- IntV
  
  for(t in 1:px$T){
    for(i.k in 1:px$num.k){
      for(i.EL in 1:px$mEL){
        for(i.pl in 1:px$p.last){
            
            IntC[, t,i.k,i.EL,i.pl] <- approxExtrap(Solution.M[t,i.h, i.k, i.EL ,i.pl,],
                                                        Solution.C[t,i.h, i.k, i.EL ,i.pl,],
                                                        DATA$Asset)$y
            
            IntV[, t,i.k,i.EL,i.pl] <- approxExtrap(Solution.M[t,i.h, i.k, i.EL ,i.pl,],
                                                        Solution.V[t,i.h, i.k, i.EL ,i.pl,],
                                                        DATA$Asset)$y
        }
      }
    }
  }
  
  out <- list("IntC" = IntC, "IntV" = IntV)
  return(out)

}

# LogLikelihood function
LogLikelihood <-function(DATA,Solution.C, Solution.M, Solution.V, px) {
  ##################################################################################
  # Description
  #
  # Loglikelihood calculation for estimating model parameters
  # 
  # Input:
  # DATA: Dataset from registerdata, N X 12 vars
  # Solution.C/V: Model soluion to consumption and values
  # Solution.M: Model endogenous grid to interpolate on
  #
  # Output:
  # llike: Sum of loglikelihood contributions
  # ProbH: Probability of the made choice given model solution
  ###################################################################################
  
  # Number of obs
  N <- nrow(DATA)
  N
  # Storage for interpolated values on choice and statse
  AltV  <- array(NA, dim = c(N, px$T, px$num.h ,px$num.k, px$mEL, px$p.last))
  AltC <- AltV
  
  # Do a parrallel loop over h from wrapper
  print("Interpolation")
  InterpCV <- foreach(x = 1:px$num.h, 
                      .combine = list,
                      .multicombine = TRUE)  %dopar%  
    
    InterpWrapperLogLike(i.h = x,
                     DATA,Solution.C, 
                     Solution.M, 
                     Solution.V,px)
  
  # Collect term
  print("Collecting Terms")
  for(i.h in 1:px$num.h){
    
    AltC[ , ,i.h , , ,] <- InterpCV[[i.h]]$IntC
    AltV[ , ,i.h , , ,] <- InterpCV[[i.h]]$IntV
    
  }
  
  PredC <- matrix(nrow = N)
  PredVh <- matrix(nrow = N,ncol = px$num.h)
  
  # Look up values for each observation
  print("Look Up Values")
  Obs <- 1:N
  
  PredC <- AltC[cbind(Obs,DATA$Age,DATA$h,DATA$k,DATA$EL,DATA$pl)]

  for(i.h in 1:px$num.h){

    PredVh[,i.h] <- AltV[cbind(Obs,DATA$Age,i.h,DATA$k,DATA$EL,DATA$pl)]
  }

  print("Calc Likelihood")
  # Model Value
  value <- PredVh[cbind(Obs, DATA$h)]
  
  # Calculate logsum
  logsum <- LogSum(PredVh, px)
  
  # Calculate Choice probs for use in model fit illustrations
  expsum <- rowSums(exp(PredVh / px$sigma.taste))
  probH <- (exp(value / px$sigma.taste)) / expsum
  
  # Choicepart of the likelihood
  choicepart <- 1 / px$sigma.taste * (value - logsum)
  
  # Consumption part of likelihood
  conspart <- - 1 / 2 * log((DATA$Cons - PredC) ^ 2)
  
  # Individual likelihoods
  IndLL <- choicepart + conspart
  
  # Total likelihood
  LogLike <- sum(choicepart + conspart)
  
  # Return output
  out <- list("SumLL" = LogLike, "IndLL" = IndLL, "choiceprob" = probH)
  
  print("Likelihood - Done!")
  return(out)
  
}

# Combined Solution and Likelihood function
FullLogLike <- function(DATA,pm,px,p1){
  ##################################################################################
  # Description
  #
  # Combined solution and loglikelihood function for a given data and parameterset
  # 
  # Input:
  # DATA: Dataset from registerdata, N X 12 vars
  # pm: model parameters to be estimated
  # px: model parameters exogenously given 
  #
  # Output:
  # llike: Sum of loglikelihood contributions
  # ProbH: Probability of the made choice given model solution
  ###################################################################################
  
  Solution <- SolveEGM(pm,px, p1)
  
  print("Shifting to Likelihood")
  
  llike <- LogLikelihood(DATA,
                         Solution.C = Solution$C,
                         Solution.M = Solution$M,
                         Solution.V = Solution$V, px)
  return(llike)
}

# Test
time <- system.time(FullLogLike(DATA, pm,px))

print(paste0("MLE evaluation time: ", round(time[[3]]/60,2), " min. per evaluation"))

# Handles for optimizer
# Sum of LogLikelihoods
LLSum <- function(pm) {
  # LogLike handle to feed to maximizer
  # Returns LL sum
 ll <- FullLogLike(DATA,pm,px,p1)
 ll <- ll$SumLL
 return(ll)
}

# Individual observations of LL for BHHH algorithm
LLObs <- function(pm) {
  # LogLike handle to feed to maximizer
  # Return individual LL contributions for all observations
  ll <- FullLogLike(DATA,pm,px)
  ll <- ll$SumLL
  return(ll)
}

# Optimizer
MLE <- maxLik(LLSum, start = pm, method = "bhhh")
